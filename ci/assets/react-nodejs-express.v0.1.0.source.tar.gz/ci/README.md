# React Node.js Express CI

This directory was taken from [kabanero-pipelines](https://github.com/kabanero-io/kabanero-pipelines/tree/master/ci).
