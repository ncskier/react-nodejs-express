# React Node.js Express Pipelines

## Package Pipelines

```sh
./ci/package.sh
```

Assets are built to `ci/assets/default-kabanero-pipelines.tar.gz`.
