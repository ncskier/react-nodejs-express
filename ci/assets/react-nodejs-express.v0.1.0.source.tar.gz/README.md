# React Node.js Express

## Build Appsody Stack

```sh
# Package stack
appsody stack package
# Move packaged stack the ci/assets/ directory
mkdir -p ci/assets/
cp -r ~/.appsody/stacks/dev.local/ ci/assets/
```
